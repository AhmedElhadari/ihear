import jwt from 'jsonwebtoken'

const SECRET = process.env.JWT_SECRET || 'ihear-secret-change-in-production'

export function signToken(payload: object) {
  return jwt.sign(payload, SECRET, { expiresIn: '30d' })
}

export function verifyToken(token: string) {
  try {
    return jwt.verify(token, SECRET) as jwt.JwtPayload
  } catch {
    return null
  }
}

export function getTokenFromHeader(authHeader: string | null) {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null
  return authHeader.slice(7)
}
