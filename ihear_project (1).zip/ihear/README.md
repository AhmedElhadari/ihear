# I Hear 🎙️ — غرف صوتية للعرب

منصة غرف صوتية تفاعلية للمجتمع العربي.

---

## 🚀 خطوات الرفع على Vercel

### 1. جهّز قاعدة البيانات

استخدم واحدة من:
- **Neon** (مجاني): https://neon.tech
- **Supabase** (مجاني): https://supabase.com
- **Vercel Postgres**: من داخل Vercel dashboard

احصل على رابط `DATABASE_URL` بهذا الشكل:
```
postgresql://user:password@host:5432/ihear?schema=public
```

---

### 2. جهّز Stripe

1. اعمل حساب على https://stripe.com
2. من **Dashboard → Developers → API Keys** خذ `Secret key`
3. من **Developers → Webhooks** أضف endpoint:
   ```
   https://your-app.vercel.app/api/payments/webhook
   ```
   وحدد هذه الأحداث: `checkout.session.completed`, `customer.subscription.deleted`
4. احصل على `Signing secret` (STRIPE_WEBHOOK_SECRET)

---

### 3. ارفع على Vercel

#### الطريقة الأسهل (من GitHub):

```bash
# 1. حمّل git وابدأ repo
git init
git add .
git commit -m "Initial commit"

# 2. ارفع على GitHub
# اعمل repo جديد على github.com ثم:
git remote add origin https://github.com/USERNAME/ihear.git
git push -u origin main
```

ثم:
1. اذهب لـ https://vercel.com
2. New Project → Import من GitHub
3. أضف Environment Variables:
   - `DATABASE_URL`
   - `JWT_SECRET`
   - `STRIPE_SECRET_KEY`
   - `STRIPE_WEBHOOK_SECRET`
   - `NEXT_PUBLIC_APP_URL` = `https://your-app.vercel.app`
4. اضغط Deploy!

---

### 4. شغّل Prisma Migrations

بعد أول deploy، شغّل في terminal:

```bash
npx prisma db push
```

أو من Vercel dashboard → Functions → Run Command.

---

## 💻 تشغيل محلي

```bash
# 1. ثبّت المكتبات
npm install

# 2. انسخ ملف البيئة
cp .env.example .env.local
# وعدّل القيم

# 3. شغّل Prisma
npx prisma generate
npx prisma db push

# 4. شغّل المشروع
npm run dev
```

افتح http://localhost:3000

---

## 📁 هيكل المشروع

```
ihear/
├── app/
│   ├── page.tsx              # اللاندنج بيج
│   ├── register/page.tsx     # صفحة التسجيل (3 خطوات)
│   ├── login/page.tsx        # صفحة الدخول
│   ├── dashboard/page.tsx    # الداشبورد
│   ├── subscribe/page.tsx    # صفحة الاشتراك
│   └── api/
│       ├── auth/register/    # API التسجيل
│       ├── auth/login/       # API الدخول
│       ├── payments/checkout/ # Stripe Checkout
│       ├── payments/webhook/  # Stripe Webhook
│       └── rooms/            # API الغرف
├── lib/
│   ├── prisma.ts             # Prisma client
│   └── auth.ts               # JWT helpers
├── prisma/
│   └── schema.prisma         # Database schema
└── styles/
    └── globals.css           # Global styles
```

---

## 🔧 Tech Stack

- **Frontend**: Next.js 14, React, Tailwind CSS
- **Backend**: Next.js API Routes
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: JWT (jsonwebtoken + bcryptjs)
- **Payments**: Stripe
- **Deployment**: Vercel
