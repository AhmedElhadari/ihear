'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Phone, Eye, EyeOff } from 'lucide-react'

export default function LoginPage() {
  const router = useRouter()
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({ email: '', password: '' })

  function set(k: string, v: string) {
    setForm(p => ({ ...p, [k]: v }))
  }

  async function handleLogin() {
    if (!form.email || !form.password) {
      setError('ادخل الإيميل وكلمة السر')
      return
    }
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || 'بيانات غلط'); setLoading(false); return }

      localStorage.setItem('ihear_token', data.token)
      localStorage.setItem('ihear_user', JSON.stringify(data.user))
      router.push('/dashboard')
    } catch {
      setError('حدث خطأ في الاتصال')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-dark-1 flex items-center justify-center px-4">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-150px] left-[-100px] w-[400px] h-[400px] rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(29,158,117,0.1) 0%, transparent 70%)' }} />
      </div>

      <div className="w-full max-w-sm relative">
        <Link href="/" className="flex items-center gap-2 justify-center mb-8">
          <div className="w-9 h-9 bg-teal-mid rounded-xl flex items-center justify-center">
            <Phone size={18} className="text-white" />
          </div>
          <span className="text-2xl font-black">I <span className="text-teal-mid">Hear</span></span>
        </Link>

        <div className="card p-8">
          <h2 className="text-2xl font-black mb-1">أهلاً بعودتك 👋</h2>
          <p className="text-gray-400 text-sm mb-6">سجّل دخولك وانضم للغرف</p>

          <div className="mb-3">
            <label className="block text-xs text-gray-400 mb-1.5">الإيميل</label>
            <input className="input-field" type="email" placeholder="email@example.com"
              value={form.email} onChange={e => set('email', e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleLogin()} />
          </div>

          <div className="mb-5">
            <label className="block text-xs text-gray-400 mb-1.5">كلمة السر</label>
            <div className="relative">
              <input className="input-field" style={{ paddingLeft: '40px' }}
                type={showPass ? 'text' : 'password'}
                placeholder="كلمة السر" value={form.password}
                onChange={e => set('password', e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleLogin()} />
              <button onClick={() => setShowPass(!showPass)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <div className="text-left mt-1.5">
              <Link href="/forgot-password" className="text-xs text-gray-500 hover:text-teal-mid transition-colors">
                نسيت كلمة السر؟
              </Link>
            </div>
          </div>

          {error && <p className="text-red-400 text-sm mb-4">{error}</p>}

          <button className="btn-primary w-full py-3 font-bold" onClick={handleLogin} disabled={loading}>
            {loading ? '⏳ جاري الدخول...' : 'دخول'}
          </button>

          <p className="text-center text-gray-500 text-xs mt-5">
            مش عندك حساب؟{' '}
            <Link href="/register" className="text-teal-mid hover:underline">سجّل الآن</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
