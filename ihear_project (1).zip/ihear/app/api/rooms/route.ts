import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const tag = searchParams.get('tag')

    const rooms = await prisma.room.findMany({
      where: {
        isLive: true,
        ...(tag && tag !== 'الكل' ? { tags: { has: tag } } : {}),
      },
      include: {
        host: {
          select: { firstName: true, lastName: true, avatarColor: true },
        },
        _count: { select: { participants: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    return NextResponse.json({ rooms })
  } catch (error) {
    console.error('Rooms error:', error)
    return NextResponse.json({ error: 'خطأ في الخادم' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { title, description, tags, hostId } = body

    const room = await prisma.room.create({
      data: {
        title,
        description,
        tags: tags || [],
        hostId,
        participants: {
          create: {
            userId: hostId,
            role: 'host',
          },
        },
      },
    })

    return NextResponse.json({ room }, { status: 201 })
  } catch (error) {
    console.error('Create room error:', error)
    return NextResponse.json({ error: 'خطأ في إنشاء الغرفة' }, { status: 500 })
  }
}
