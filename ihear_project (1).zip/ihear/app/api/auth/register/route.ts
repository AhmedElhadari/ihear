import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { signToken } from '@/lib/auth'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { firstName, lastName, email, password, country, languages, bio, avatarColor } = body

    // Validation
    if (!firstName || !email || !password) {
      return NextResponse.json({ error: 'كل الحقول مطلوبة' }, { status: 400 })
    }

    if (password.length < 8) {
      return NextResponse.json({ error: 'كلمة السر ٨ أحرف على الأقل' }, { status: 400 })
    }

    // Check existing user
    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) {
      return NextResponse.json({ error: 'هذا الإيميل مسجل بالفعل' }, { status: 400 })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create user
    const user = await prisma.user.create({
      data: {
        firstName,
        lastName: lastName || '',
        email,
        password: hashedPassword,
        country: country || 'EG',
        languages: languages || ['العربية'],
        bio: bio || '',
        avatarColor: avatarColor || '#1D9E75',
      },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        country: true,
        languages: true,
        bio: true,
        avatarColor: true,
        isSubscribed: true,
        createdAt: true,
      }
    })

    const token = signToken({ userId: user.id, email: user.email })

    return NextResponse.json({ token, user }, { status: 201 })
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}
