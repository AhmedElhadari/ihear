'use client'
import Link from 'next/link'
import { Phone, Mic, Users, Globe, Zap, Star, ArrowLeft, Play, TrendingUp, Shield } from 'lucide-react'
import { useState, useEffect } from 'react'

const LIVE_ROOMS = [
  { id: 1, title: 'مستقبل الذكاء الاصطناعي في الوطن العربي', host: 'أحمد الشريف', listeners: 342, tags: ['تكنولوجيا', 'AI'], color: '#1D9E75' },
  { id: 2, title: 'نقاش: أفضل اقتصاديات الخليج 2025', host: 'سارة المنصوري', listeners: 218, tags: ['اقتصاد', 'خليج'], color: '#7F77DD' },
  { id: 3, title: 'ريادة الأعمال من الصفر — قصص نجاح حقيقية', host: 'محمد الحسن', listeners: 189, tags: ['ريادة', 'إلهام'], color: '#D85A30' },
  { id: 4, title: 'الصحة النفسية في العالم العربي — كسر الصمت', host: 'د. نور الدين', listeners: 156, tags: ['صحة', 'نقاش'], color: '#D4537E' },
]

const STATS = [
  { value: '50K+', label: 'مستخدم نشط', icon: Users },
  { value: '1,200+', label: 'غرفة يومياً', icon: Mic },
  { value: '15+', label: 'دولة عربية', icon: Globe },
  { value: '4.9★', label: 'تقييم المستخدمين', icon: Star },
]

const FEATURES = [
  {
    icon: Mic,
    title: 'غرف صوتية عالية الجودة',
    desc: 'صوت نقي بدون تأخير مع تقنية WebRTC المتطورة',
    color: '#1D9E75',
  },
  {
    icon: Users,
    title: 'مجتمع عربي حقيقي',
    desc: 'تواصل مع متحدثين من مصر والخليج والمغرب وأكثر',
    color: '#7F77DD',
  },
  {
    icon: Shield,
    title: 'خصوصية وأمان',
    desc: 'محادثاتك محمية بالكامل. لا تسجيل بدون إذنك',
    color: '#D85A30',
  },
  {
    icon: Zap,
    title: 'انضم فوراً',
    desc: 'ادخل أي غرفة في ثانية واحدة بدون انتظار',
    color: '#D4537E',
  },
  {
    icon: TrendingUp,
    title: 'اكتشف الترند',
    desc: 'شاهد أكثر الغرف اهتماماً في الوقت الحقيقي',
    color: '#BA7517',
  },
  {
    icon: Globe,
    title: 'متعدد اللغات',
    desc: 'عربي وانجليزي وفرنسي — احكي بأي لغة تحب',
    color: '#185FA5',
  },
]

export default function LandingPage() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <div className="min-h-screen bg-dark-1 text-white overflow-x-hidden" dir="rtl">
      {/* Background blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-200px] right-[-200px] w-[600px] h-[600px] rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(29,158,117,0.12) 0%, transparent 70%)' }} />
        <div className="absolute bottom-[-200px] left-[-200px] w-[500px] h-[500px] rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(127,119,221,0.08) 0%, transparent 70%)' }} />
      </div>

      {/* Navbar */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-dark-1/90 backdrop-blur-md border-b border-white/5' : ''}`}>
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-9 h-9 bg-teal-mid rounded-xl flex items-center justify-center">
              <Phone size={18} className="text-white" />
            </div>
            <span className="text-xl font-black">I <span className="text-teal-mid">Hear</span></span>
          </Link>

          <div className="hidden md:flex items-center gap-8 text-sm text-gray-400">
            <Link href="#features" className="hover:text-white transition-colors">المميزات</Link>
            <Link href="#rooms" className="hover:text-white transition-colors">الغرف المباشرة</Link>
            <Link href="#pricing" className="hover:text-white transition-colors">الأسعار</Link>
          </div>

          <div className="flex items-center gap-3">
            <Link href="/login" className="btn-outline py-2 px-4 text-sm">دخول</Link>
            <Link href="/register" className="btn-primary py-2 px-4 text-sm">ابدأ مجاناً</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative pt-32 pb-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-teal-mid/10 border border-teal-mid/30 rounded-full px-4 py-2 text-sm text-teal-mid mb-8 animate-fade-in">
            <span className="live-dot" />
            ١,٢٠٠+ غرفة مباشرة الآن
          </div>

          <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight animate-slide-up">
            صوتك يوصل
            <br />
            <span className="text-teal-mid">للعالم العربي</span>
          </h1>

          <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.1s' }}>
            انضم لآلاف العرب في غرف صوتية حية. ناقش، اتعلم، شارك آراءك
            في مجتمع عربي حقيقي.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <Link href="/register"
              className="btn-primary py-4 px-8 text-lg font-bold animate-pulse-glow">
              ابدأ مجاناً — $2/شهر
              <ArrowLeft size={20} />
            </Link>
            <button className="btn-outline py-4 px-8 text-lg flex items-center gap-2">
              <Play size={18} />
              شاهد كيف يشتغل
            </button>
          </div>

          <p className="text-gray-500 text-sm mt-4">لا بطاقة ائتمان مطلوبة للتجربة • إلغاء في أي وقت</p>
        </div>
      </section>

      {/* Stats */}
      <section className="px-6 pb-20">
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          {STATS.map((s, i) => (
            <div key={i} className="card p-5 text-center animate-fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
              <s.icon size={20} className="text-teal-mid mx-auto mb-2" />
              <div className="text-2xl font-black text-white">{s.value}</div>
              <div className="text-xs text-gray-500 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Live Rooms Preview */}
      <section id="rooms" className="px-6 pb-24">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-8">
            <div className="live-badge">
              <span className="live-dot" /> مباشر الآن
            </div>
            <h2 className="text-2xl font-black">غرف نشطة الآن</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {LIVE_ROOMS.map((room, i) => (
              <div key={room.id} className="room-card animate-fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: room.color + '20', color: room.color }}>
                    <Mic size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm mb-1 leading-snug">{room.title}</h3>
                    <p className="text-gray-500 text-xs mb-2">بقيادة {room.host}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex gap-1">
                        {room.tags.map(t => (
                          <span key={t} className="text-xs px-2 py-0.5 rounded-full"
                            style={{ background: room.color + '15', color: room.color }}>
                            {t}
                          </span>
                        ))}
                      </div>
                      <div className="flex items-center gap-1 text-gray-500 text-xs">
                        <Users size={12} />
                        {room.listeners.toLocaleString('ar-EG')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-6">
            <Link href="/register" className="btn-outline py-2.5 px-6 text-sm">
              شوف كل الغرف
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="px-6 pb-24">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black mb-3">ليه I Hear؟</h2>
            <p className="text-gray-400">منصة مصممة خصيصاً للمجتمع العربي</p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {FEATURES.map((f, i) => (
              <div key={i} className="card p-6 animate-fade-in" style={{ animationDelay: `${i * 0.08}s` }}>
                <div className="w-10 h-10 rounded-xl mb-4 flex items-center justify-center"
                  style={{ background: f.color + '20' }}>
                  <f.icon size={20} style={{ color: f.color }} />
                </div>
                <h3 className="font-bold mb-2 text-sm">{f.title}</h3>
                <p className="text-gray-500 text-xs leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="px-6 pb-24">
        <div className="max-w-sm mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-black mb-2">سعر بسيط وصريح</h2>
            <p className="text-gray-400 text-sm">بدون رسوم خفية. بدون مفاجآت.</p>
          </div>

          <div className="card p-8 text-center glow-teal relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 rounded-full"
              style={{ background: 'radial-gradient(circle, rgba(29,158,117,0.15) 0%, transparent 70%)', transform: 'translate(30%, -30%)' }} />

            <div className="text-5xl font-black text-teal-mid mb-1">$2</div>
            <div className="text-gray-400 text-sm mb-6">شهرياً فقط</div>

            <ul className="text-sm text-right mb-8 space-y-3">
              {[
                'وصول لكل الغرف المباشرة',
                'إنشاء غرفك الخاصة',
                'ميزات المتحدث والمضيف',
                'دعم فني على مدار اليوم',
                'تحديثات مجانية للأبد',
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3">
                  <span className="text-teal-mid text-base">✓</span>
                  {item}
                </li>
              ))}
            </ul>

            <Link href="/register" className="btn-primary w-full py-3 font-bold block text-center">
              ابدأ الآن
            </Link>
            <p className="text-gray-600 text-xs mt-3">إلغاء في أي وقت</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 pb-24">
        <div className="max-w-2xl mx-auto text-center card p-12 relative overflow-hidden">
          <div className="absolute inset-0 opacity-5"
            style={{ backgroundImage: 'repeating-linear-gradient(45deg, #1D9E75 0, #1D9E75 1px, transparent 0, transparent 50%)', backgroundSize: '10px 10px' }} />
          <div className="relative">
            <h2 className="text-3xl font-black mb-3">جاهز تنضم؟</h2>
            <p className="text-gray-400 mb-8">انضم لأكثر من ٥٠,٠٠٠ عربي يستخدمون I Hear يومياً</p>
            <Link href="/register" className="btn-primary py-4 px-10 text-lg font-bold inline-flex">
              سجّل الآن — مجاناً
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 px-6 py-8">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-teal-mid rounded-lg flex items-center justify-center">
              <Phone size={14} className="text-white" />
            </div>
            <span className="font-black">I <span className="text-teal-mid">Hear</span></span>
          </div>
          <div className="flex gap-6 text-sm text-gray-500">
            <Link href="/privacy" className="hover:text-white transition-colors">الخصوصية</Link>
            <Link href="/terms" className="hover:text-white transition-colors">الشروط</Link>
            <Link href="/contact" className="hover:text-white transition-colors">اتصل بنا</Link>
          </div>
          <p className="text-gray-600 text-xs">© 2025 I Hear. كل الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  )
}
