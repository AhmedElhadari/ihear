'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Phone, Mic, Users, Plus, Search, LogOut, Bell, Hash } from 'lucide-react'

const MOCK_ROOMS = [
  { id: '1', title: 'مستقبل الذكاء الاصطناعي في الوطن العربي', host: 'أحمد الشريف', hostColor: '#1D9E75', listeners: 342, tags: ['تكنولوجيا', 'AI'], isLive: true },
  { id: '2', title: 'نقاش: أفضل اقتصاديات الخليج 2025', host: 'سارة المنصوري', hostColor: '#7F77DD', listeners: 218, tags: ['اقتصاد'], isLive: true },
  { id: '3', title: 'ريادة الأعمال من الصفر', host: 'محمد الحسن', hostColor: '#D85A30', listeners: 189, tags: ['ريادة'], isLive: true },
  { id: '4', title: 'الصحة النفسية في العالم العربي', host: 'د. نور الدين', hostColor: '#D4537E', listeners: 156, tags: ['صحة'], isLive: true },
  { id: '5', title: 'تعلم البرمجة في 2025 — من أين تبدأ؟', host: 'خالد النعيمي', hostColor: '#BA7517', listeners: 97, tags: ['تعليم', 'تكنولوجيا'], isLive: false },
  { id: '6', title: 'السياحة في العالم العربي — تجارب حقيقية', host: 'ليلى الزهراني', hostColor: '#185FA5', listeners: 74, tags: ['سياحة'], isLive: false },
]

const CATEGORIES = ['الكل', 'تكنولوجيا', 'اقتصاد', 'ريادة', 'صحة', 'تعليم', 'ثقافة', 'رياضة']

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<{ firstName?: string; avatarColor?: string } | null>(null)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('الكل')

  useEffect(() => {
    const u = localStorage.getItem('ihear_user')
    if (!u) { router.push('/login'); return }
    setUser(JSON.parse(u))
  }, [router])

  function logout() {
    localStorage.removeItem('ihear_token')
    localStorage.removeItem('ihear_user')
    router.push('/')
  }

  const filtered = MOCK_ROOMS.filter(r => {
    const matchSearch = r.title.includes(search) || r.host.includes(search)
    const matchCat = category === 'الكل' || r.tags.includes(category)
    return matchSearch && matchCat
  })

  return (
    <div className="min-h-screen bg-dark-1" dir="rtl">
      {/* Sidebar */}
      <aside className="fixed right-0 top-0 h-full w-60 bg-dark-2 border-l border-white/5 flex flex-col z-40 hidden md:flex">
        <div className="p-5 border-b border-white/5">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-teal-mid rounded-xl flex items-center justify-center">
              <Phone size={16} className="text-white" />
            </div>
            <span className="text-lg font-black">I <span className="text-teal-mid">Hear</span></span>
          </Link>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-teal-mid/10 text-teal-mid cursor-pointer">
            <Hash size={16} /> <span className="text-sm font-semibold">الغرف</span>
          </div>
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-gray-400 hover:bg-white/5 cursor-pointer transition-colors">
            <Users size={16} /> <span className="text-sm">المجتمع</span>
          </div>
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-gray-400 hover:bg-white/5 cursor-pointer transition-colors">
            <Bell size={16} /> <span className="text-sm">الإشعارات</span>
          </div>
        </nav>

        {/* User */}
        <div className="p-4 border-t border-white/5">
          <div className="flex items-center gap-3">
            <div className="avatar w-9 h-9 text-sm" style={{ background: user?.avatarColor || '#1D9E75' }}>
              {user?.firstName?.[0]?.toUpperCase() || 'أ'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate">{user?.firstName || 'مستخدم'}</p>
              <p className="text-xs text-gray-500">عضو نشط</p>
            </div>
            <button onClick={logout} className="text-gray-500 hover:text-red-400 transition-colors">
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="md:mr-60 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-black">الغرف المباشرة 🎙️</h1>
            <p className="text-gray-400 text-sm mt-1">{filtered.filter(r => r.isLive).length} غرفة مباشرة الآن</p>
          </div>
          <button className="btn-primary py-2.5 px-4 text-sm flex items-center gap-2">
            <Plus size={16} />
            غرفة جديدة
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            className="input-field pr-9"
            placeholder="ابحث عن غرفة..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-none">
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                category === cat
                  ? 'bg-teal-mid text-white'
                  : 'border border-white/10 text-gray-400 hover:border-white/20'
              }`}>
              {cat}
            </button>
          ))}
        </div>

        {/* Rooms Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((room, i) => (
            <div key={room.id} className="room-card animate-fade-in" style={{ animationDelay: `${i * 0.05}s` }}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: room.hostColor + '20', color: room.hostColor }}>
                  <Mic size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="font-bold text-sm leading-snug line-clamp-2">{room.title}</h3>
                    {room.isLive && (
                      <div className="live-badge flex-shrink-0">
                        <span className="live-dot" /> Live
                      </div>
                    )}
                  </div>
                  <p className="text-gray-500 text-xs mb-2">بقيادة {room.host}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-1 flex-wrap">
                      {room.tags.map(t => (
                        <span key={t} className="text-xs px-2 py-0.5 rounded-full"
                          style={{ background: room.hostColor + '15', color: room.hostColor }}>
                          {t}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center gap-1 text-gray-500 text-xs">
                      <Users size={11} />
                      {room.listeners.toLocaleString('ar-EG')}
                    </div>
                  </div>
                </div>
              </div>

              <button className="w-full mt-3 py-2 text-xs font-bold rounded-lg border border-teal-mid/30 text-teal-mid hover:bg-teal-mid hover:text-white transition-all">
                انضم للغرفة
              </button>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-gray-500">
            <Mic size={40} className="mx-auto mb-3 opacity-20" />
            <p>ما فيه غرف بهذا البحث</p>
          </div>
        )}
      </main>

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-dark-2 border-t border-white/5 flex md:hidden">
        <button className="flex-1 py-3 flex flex-col items-center gap-1 text-teal-mid">
          <Hash size={20} />
          <span className="text-[10px]">الغرف</span>
        </button>
        <button className="flex-1 py-3 flex flex-col items-center gap-1 text-gray-500">
          <Users size={20} />
          <span className="text-[10px]">المجتمع</span>
        </button>
        <button className="flex-1 py-3 flex flex-col items-center gap-1 text-gray-500">
          <Bell size={20} />
          <span className="text-[10px]">الإشعارات</span>
        </button>
        <button onClick={logout} className="flex-1 py-3 flex flex-col items-center gap-1 text-gray-500">
          <LogOut size={20} />
          <span className="text-[10px]">خروج</span>
        </button>
      </nav>
    </div>
  )
}
