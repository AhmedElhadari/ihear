import type { Metadata } from 'next'
import '../styles/globals.css'

export const metadata: Metadata = {
  title: 'I Hear — غرف صوتية للعرب',
  description: 'منصة غرف صوتية تفاعلية للمجتمع العربي. انضم لآلاف المتحدثين وشارك آراءك.',
  keywords: ['غرف صوتية', 'عربي', 'بودكاست', 'نقاشات', 'IHear'],
  openGraph: {
    title: 'I Hear — غرف صوتية للعرب',
    description: 'منصة غرف صوتية تفاعلية للمجتمع العربي',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
