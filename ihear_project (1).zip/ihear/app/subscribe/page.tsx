'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Phone, CheckCircle } from 'lucide-react'

export default function SubscribePage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [user, setUser] = useState<{ firstName?: string } | null>(null)

  useEffect(() => {
    const u = localStorage.getItem('ihear_user')
    if (!u) { router.push('/login'); return }
    setUser(JSON.parse(u))
  }, [router])

  async function handleSubscribe() {
    setLoading(true)
    try {
      const token = localStorage.getItem('ihear_token')
      const res = await fetch('/api/payments/create-checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      })
      const data = await res.json()
      if (data.url) {
        window.location.href = data.url
      }
    } catch {
      console.error('Checkout error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-dark-1 flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <Link href="/" className="flex items-center gap-2 justify-center mb-8">
          <div className="w-9 h-9 bg-teal-mid rounded-xl flex items-center justify-center">
            <Phone size={18} className="text-white" />
          </div>
          <span className="text-2xl font-black">I <span className="text-teal-mid">Hear</span></span>
        </Link>

        <div className="card p-8 text-center">
          <div className="w-16 h-16 bg-teal-mid/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-teal-mid" />
          </div>

          <h2 className="text-2xl font-black mb-2">تم إنشاء حسابك! 🎉</h2>
          <p className="text-gray-400 text-sm mb-6">
            أهلاً {user?.firstName}! خطوة واحدة بس وتبدأ
          </p>

          <div className="bg-dark-3 rounded-xl p-4 mb-6 text-sm text-right">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-400">الاشتراك الشهري</span>
              <span className="font-bold text-white">$2.00/شهر</span>
            </div>
            <div className="flex justify-between items-center text-xs text-gray-500">
              <span>Stripe Secure Payment</span>
              <span>🔒 محمي بالكامل</span>
            </div>
          </div>

          <button className="btn-primary w-full py-3 font-bold mb-3" onClick={handleSubscribe} disabled={loading}>
            {loading ? '⏳ جاري التوجيه...' : '💳 ادفع الآن عبر Stripe'}
          </button>

          <button className="btn-outline w-full py-2.5 text-sm" onClick={() => router.push('/dashboard')}>
            تخطي الآن (وصول محدود)
          </button>
        </div>
      </div>
    </div>
  )
}
